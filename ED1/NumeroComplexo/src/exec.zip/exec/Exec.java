package exec;
public class Exec {
	public static void main(String[] args) {
		NumeroComplexo NC = new NumeroComplexo(2,3,4,5);
		NC.soma();
		NC.subtracao();
		NC.multiplicacao();
		NC.divisao();

	}

}
